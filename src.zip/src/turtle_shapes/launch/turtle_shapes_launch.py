from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtle_shapes',
            executable='shape_node',
            name='shapeNode',
            output='screen'
        ),
        Node(
            package='turtle_shapes',
            executable='turtle_commander',
            name='turtleCommander',
            output='screen'
        ),
    ])
