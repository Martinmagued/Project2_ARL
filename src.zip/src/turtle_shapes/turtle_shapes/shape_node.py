#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class ShapeNode(Node):
    def __init__(self):
        super().__init__('shapeNode')
        self.publisher = self.create_publisher(String, 'shape_topic', 10)

        # Original shapes + new text shape
        self.available_shapes = ['heart','spiral','infinity','flower','lissajous','star', 'roar']
        self.commands = ['stop','clear','clear_screen','turbo','normal']

        self.get_logger().info(
            "✅ ShapeNode started.\n"
            "Available shapes: " + ", ".join(self.available_shapes) + "\n"
            "Commands: " + ", ".join(self.commands)
        )

    def run(self):
        try:
            while rclpy.ok():
                # Show menu each time
                print("\nShapes: " + ", ".join(self.available_shapes))
                print("Commands: stop, clear, turbo, normal")
                user_input = input("Enter shape or command: ").strip().lower()

                if user_input in self.available_shapes + self.commands:
                    msg = String()
                    msg.data = user_input
                    self.publisher.publish(msg)
                    self.get_logger().info(f"Published: {user_input}")
                else:
                    self.get_logger().warn(f"Invalid input '{user_input}'. Please choose from the list above.")
        except KeyboardInterrupt:
            self.get_logger().info("ShapeNode stopped by user.")

def main(args=None):
    rclpy.init(args=args)
    node = ShapeNode()
    try:
        node.run()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
