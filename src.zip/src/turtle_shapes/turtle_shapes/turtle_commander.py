#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import TeleportAbsolute, SetPen
from std_srvs.srv import Empty
import math

class TurtleCommander(Node):
    def __init__(self):
        super().__init__('turtleCommander')

        # pub/sub
        self.create_subscription(String, 'shape_topic', self.shape_callback, 10)
        self.create_subscription(Pose, '/turtle1/pose', self.pose_callback, 10)
        self.cmd_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)

        # service clients
        self.teleport_client = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute')
        self.setpen_client = self.create_client(SetPen, '/turtle1/set_pen')
        self.clear_client = self.create_client(Empty, '/clear')

        self.current_pose = None
        self.shape = None
        self.points = []
        self.idx = 0
        self.drawing = False
        self.turbo = False  # turbo mode OFF by default

        # for multi-segment shapes (letters)
        self.letter_segments = []
        self.segment_idx = 0

        self.timer = self.create_timer(0.02, self.timer_callback)  # 50 Hz

        self.get_logger().info("turtleCommander ready. Waiting for shape commands...")

    # ---------------------- service helpers ----------------------
    def wait_for_service(self, client, name: str, max_wait_sec=5.0):
        waited = 0.0
        step = 0.3
        while rclpy.ok() and not client.wait_for_service(timeout_sec=step):
            waited += step
            if waited >= max_wait_sec:
                self.get_logger().warn(f"Service {name} not available after {max_wait_sec}s")
                return False
        return True

    def call_teleport(self, x: float, y: float, theta: float) -> bool:
        if not self.wait_for_service(self.teleport_client, '/turtle1/teleport_absolute', 6.0):
            self.get_logger().error("Teleport service not available")
            return False
        req = TeleportAbsolute.Request()
        req.x = float(x); req.y = float(y); req.theta = float(theta)
        fut = self.teleport_client.call_async(req)
        rclpy.spin_until_future_complete(self, fut, timeout_sec=3.0)
        return True

    def call_set_pen(self, r: int, g: int, b: int, width: int, off: int) -> bool:
        if not self.wait_for_service(self.setpen_client, '/turtle1/set_pen', 6.0):
            self.get_logger().error("SetPen service not available")
            return False
        req = SetPen.Request()
        req.r = int(r); req.g = int(g); req.b = int(b)
        req.width = int(width); req.off = int(off)
        fut = self.setpen_client.call_async(req)
        rclpy.spin_until_future_complete(self, fut, timeout_sec=3.0)
        return True

    def call_clear(self) -> bool:
        if not self.wait_for_service(self.clear_client, '/clear', 6.0):
            self.get_logger().error("Clear service not available")
            return False
        fut = self.clear_client.call_async(Empty.Request())
        rclpy.spin_until_future_complete(self, fut, timeout_sec=3.0)
        return True

    # ---------------------- sample shapes ----------------------
    def sample_shape(self, shape_name: str):
        pts = []

        if shape_name == 'heart':
            t0, t1, n = 0.0, 2*math.pi, 400
            for i in range(n):
                t = t0 + (t1-t0)*i/(n-1)
                x = 16*math.sin(t)**3
                y = 13*math.cos(t)-5*math.cos(2*t)-2*math.cos(3*t)-math.cos(4*t)
                pts.append((x,y))

        elif shape_name == 'spiral':
            t0, t1, n = 0.0, 6*math.pi, 700
            a = 0.5
            for i in range(n):
                t = t0 + (t1-t0)*i/(n-1)
                x = a*t*math.cos(t)
                y = a*t*math.sin(t)
                pts.append((x,y))

        elif shape_name == 'infinity':
            t0, t1, n = 0.0, 2*math.pi, 400
            a = 5.0
            for i in range(n):
                t = t0 + (t1-t0)*i/(n-1)
                denom = 1 + math.sin(t)**2
                x = (a*math.cos(t))/denom
                y = (a*math.cos(t)*math.sin(t))/denom
                pts.append((x,y))

        elif shape_name == 'flower':
            t0, t1, n = 0.0, 2*math.pi, 500
            k = 5
            for i in range(n):
                t = t0 + (t1-t0)*i/(n-1)
                r = 5*math.cos(k*t)
                x = r*math.cos(t)
                y = r*math.sin(t)
                pts.append((x,y))

        elif shape_name == 'lissajous':
            t0, t1, n = 0.0, 2*math.pi, 700
            A = 5; B = 5; a = 3; b = 2; delta = math.pi/2
            for i in range(n):
                t = t0 + (t1-t0)*i/(n-1)
                x = A*math.sin(a*t+delta)
                y = B*math.sin(b*t)
                pts.append((x,y))

        elif shape_name == 'star':
            t0, t1, n = 0.0, 2*math.pi, 500
            r = 5; n_points = 5
            for i in range(n):
                t = t0 + (t1-t0)*i/(n-1)
                radius = r*(0.3+0.7*(0.5+0.5*math.cos(n_points*t)))
                x = radius*math.cos(t)
                y = radius*math.sin(t)
                pts.append((x,y))


        elif shape_name == 'roar':
            # Define letters with simple line strokes
            letter_paths = []
            def letter_R(dx=0.0):

                return [

                    (0 + dx, 0), (0 + dx, 2),  # vertical
                    (1 + dx, 2), (1.2 + dx, 1.5), (1 + dx, 1), (0 + dx, 1),  # loop
                    (1 + dx, 0)  # diagonal leg
                ]
            def letter_O(dx=0.0):
                pts = []
                for i in range(60):
                    t = 2 * math.pi * i / 59

                    pts.append((dx + math.cos(t) * 0.8 + 0.8, math.sin(t) * 1.0 + 1.0))
                return pts
            def letter_A(dx=0.0):

                return [
                    (0 + dx, 0), (0.8 + dx, 2), (1.6 + dx, 0),  # /\ shape
                    (0.4 + dx, 1), (1.2 + dx, 1)  # crossbar
                ]
            # spacing between letters
            spacing = 3.0
            letter_paths.append(letter_R(0 * spacing))
            letter_paths.append(letter_O(1 * spacing))
            letter_paths.append(letter_A(2 * spacing))
            letter_paths.append(letter_R(3 * spacing))
            # Flatten all letters for bounding box scaling

            all_pts = [p for seg in letter_paths for p in seg]
            xs = [p[0] for p in all_pts];
            ys = [p[1] for p in all_pts]
            min_x, max_x = min(xs), max(xs);
            min_y, max_y = min(ys), max(ys)
            span_x = max_x - min_x + 1e-9;
            span_y = max_y - min_y + 1e-9
            margin = 0.6;
            allowed = 11.0 - 2 * margin
            scale = min(allowed / span_x, allowed / span_y) * 0.9
            cx = (min_x + max_x) / 2.0;
            cy = (min_y + max_y) / 2.0
            scaled_paths = []
            for seg in letter_paths:
                scaled_paths.append([((x - cx) * scale + 5.5, (y - cy) * scale + 5.5) for (x, y) in seg])

            return scaled_paths

        # dynamic scaling for normal shapes
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        min_x, max_x = min(xs), max(xs); min_y, max_y = min(ys), max(ys)
        span_x = max_x - min_x + 1e-9; span_y = max_y - min(ys) + 1e-9
        margin = 0.6
        allowed = 11.0 - 2*margin
        scale = min(allowed/span_x, allowed/span_y)*0.9
        cx = (min_x+max_x)/2.0; cy = (min_y+max_y)/2.0
        mapped = [((xr-cx)*scale+5.5, (yr-cy)*scale+5.5) for (xr,yr) in pts]
        return mapped

    # ---------------------- callbacks ----------------------
    def shape_callback(self, msg: String):
        cmd = msg.data.strip().lower()

        # turbo commands
        if cmd == 'turbo':
            self.turbo = True
            self.get_logger().info("Turbo mode ON! 🚀")
            return
        elif cmd == 'normal':
            self.turbo = False
            self.get_logger().info("Turbo mode OFF. 🐢")
            return

        self.get_logger().info(f"shape command: '{cmd}'")

        if cmd in ['clear','clear_screen']:
            if self.call_clear():
                self.get_logger().info("Screen cleared.")
            return

        if cmd == 'stop':
            self.drawing=False; self.shape=None; self.points=[]; self.idx=0
            self.cmd_pub.publish(Twist()); self.call_set_pen(0,0,0,0,1)
            self.get_logger().info("Stopped drawing.")
            return

        pts = self.sample_shape(cmd)
        if not pts:
            self.get_logger().warn(f"Unknown shape '{cmd}'")
            return

        # If multi-segment (like ROAR)
        if isinstance(pts[0][0], tuple):
            self.shape = cmd
            self.letter_segments = pts
            self.segment_idx = 0
            self.start_next_segment()
        else:
            self.shape = cmd
            self.start_segment(pts)

    def pose_callback(self, pose: Pose):
        self.current_pose=pose

    # ---------------------- segment handling ----------------------
    def start_next_segment(self):
        if self.segment_idx >= len(self.letter_segments):
            self.get_logger().info(f"Finished '{self.shape}'.")
            self.drawing=False; self.shape=None; self.points=[]; self.idx=0
            return
        seg = self.letter_segments[self.segment_idx]
        self.segment_idx += 1
        self.start_segment(seg)

    def start_segment(self, pts):
        self.points = pts
        self.idx = 1 if len(pts)>1 else 0
        self.call_set_pen(0,0,0,0,1)  # lift pen
        x0,y0 = pts[0]
        theta0 = math.atan2(pts[1][1]-y0, pts[1][0]-x0) if len(pts)>1 else 0.0
        self.call_teleport(x0,y0,theta0)
        self.call_set_pen(0,0,0,2,0)  # put pen down
        self.drawing = True
        self.get_logger().info(f"Starting segment with {len(pts)} points.")

    # ---------------------- main timer ----------------------
    def timer_callback(self):
        if not self.drawing or not self.points or self.current_pose is None:
            return
        if self.idx >= len(self.points):
            self.get_logger().info(f"Finished one segment of '{self.shape}'.")
            self.drawing = False
            self.start_next_segment()
            return

        tx,ty=self.points[self.idx]; px,py=self.current_pose.x,self.current_pose.y
        dx,dy=tx-px,ty-py; dist=math.hypot(dx,dy)
        angle_to_goal=math.atan2(dy,dx)
        angle_error=math.atan2(math.sin(angle_to_goal-self.current_pose.theta),
                               math.cos(angle_to_goal-self.current_pose.theta))

        # controller speeds (turbo multiplies by 5.0)
        factor = 5.0 if self.turbo else 1.0
        K_lin=3.0*factor; K_ang=6.0*factor; max_lin=4.0*factor; max_ang=6.0*factor
        lin = min(max_lin, K_lin*dist) if abs(angle_error)<0.5 else 0.2*min(max_lin, K_lin*dist)
        ang = max(-max_ang, min(max_ang, K_ang*angle_error))
        twist = Twist()
        twist.linear.x = lin
        twist.angular.z = ang
        self.cmd_pub.publish(twist)

        if dist<0.06: self.idx+=1

def main(args=None):
    rclpy.init(args=args)
    node=TurtleCommander()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    node.destroy_node(); rclpy.shutdown()

if __name__=='__main__':
    main()
